from __future__ import annotations

import re

from ...models import Position, Reference, ReferenceType
from .journal import parse_authors

# The pages character class includes the en-dash (U+2013) which APA style uses
# for page ranges. We build it via chr() to avoid a literal ambiguous character
# that ruff would flag as RUF001.
_EN_DASH = chr(0x2013)

_RE = re.compile(
    r"""
    ^(?P<authors>.+?)\s*
    \((?P<year>\d{4}[a-z]?)\)\.\s*
    (?P<title>[^.]+?)\.\s*
    In\s+(?P<editors>[^()]+?)\s*\(Eds?\.\),\s*
    (?P<container>[^()]+?)\s*
    \(pp\.\s*(?P<pages>[\d\-"""
    + _EN_DASH
    + r"""]+)\)\.\s*
    (?P<publisher>[A-Z][^.]+?)\.?\s*$
    """,
    re.VERBOSE,
)


def try_parse_book_chapter(raw: str, position_start: int) -> Reference | None:
    m = _RE.match(raw.strip())
    if not m:
        return None
    return Reference(
        raw=raw,
        ref_type=ReferenceType.BOOK_CHAPTER,
        authors=parse_authors(m.group("authors")),
        year=m.group("year"),
        title=m.group("title").strip(),
        container=m.group("container").strip(),
        pages=m.group("pages").strip(),
        publisher=m.group("publisher").strip(),
        extras={"editors": m.group("editors").strip()},
        position=Position(start=position_start, end=position_start + len(raw)),
    )
